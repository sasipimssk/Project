package com.example.tester;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private Button btn_detail;
    View v;
    RecyclerView recyclerView;
    ArrayList<Model> models ;
    MyAdapter myAdapter;

    public HomeFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_home, container, false);
        recyclerView = v.findViewById(R.id.recyclerViewId);
        myAdapter = new MyAdapter(models,getContext());
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));


        return v;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        models = new ArrayList<>();

        Model m = new Model();
        m.setTitle("SWIMMING");
        m.setDescription("Preliminary Round \nWomen");
        m.setVenue("Tokyo Stadium");
        m.setDate("16/06/2020");
        m.setStart("14.00");
        m.setDuration("3.0 hrs");
        m.setTravel("30 minutes");
        m.setImg(R.drawable.ic_launcher_background);
        models.add(m);

        m = new Model();
        m.setTitle("RUNNING");
        m.setDescription("Preliminary Round \nMen");
        m.setVenue("Tokyo Stadium");
        m.setDate("17/06/2020");
        m.setStart("15.00");
        m.setDuration("3.0 hrs");
        m.setTravel("30 minutes");
        m.setImg(R.drawable.ic_launcher_background);
        models.add(m);

        m = new Model();
        m.setTitle("CYCLING");
        m.setDescription("Preliminary Round \nWomen");
        m.setVenue("Tokyo Stadium");
        m.setDate("15/06/2020");
        m.setStart("16.00");
        m.setDuration("2.0 hrs");
        m.setTravel("30 minutes");
        m.setImg(R.drawable.ic_launcher_background);
        models.add(m);


    }
}


