package com.example.tester.Model_login;

public class User {
    private String name,username,password,cardno;

    public User(){

    }

    public String getName_lg() {
        return name;
    }

    public String getUsername_lg() {
        return username;
    }

    public String getPassword_lg() {
        return password;
    }

    public String getCardno_lg() {
        return cardno;
    }

    public void setName_lg(String name) {
        this.name = name;
    }

    public void setUsername_lg(String username) {
        this.username = username;
    }

    public void setPassword_lg(String password) {
        this.password = password;
    }

    public void setCardno_lg(String cardno) {
        this.cardno = cardno;
    }

    public User(String name, String username, String password, String cardno){
        this.name = name;
        this.username =username;
        this.password =password;
        this.cardno =cardno;

    }
}
