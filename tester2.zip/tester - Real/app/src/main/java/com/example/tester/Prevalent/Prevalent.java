package com.example.tester.Prevalent;


import com.example.tester.Model_login.User;

public class Prevalent
{
    private static User currentOnlineUser;
}
